<?php
// Heading
$_['heading_title']    = 'XML import-export module';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified XML import-export module!';
$_['text_edit']        = 'Edit XML import-export module';
$_['text_import']	   = 'Import';
$_['text_export']	   = 'Export';
$_['text_tips_import']	   = 'Import goods';
$_['text_import_success']	   = 'All goods was imported!';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module XML import-export module!';